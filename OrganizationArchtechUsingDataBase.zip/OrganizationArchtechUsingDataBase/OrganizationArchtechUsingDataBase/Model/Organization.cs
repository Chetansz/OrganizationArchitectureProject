﻿namespace OrganizationArchitecture.Model
{
    public class Organization : BaseEntity
    {

        public Guid Id { get; set; }
        public string? Name { get; set; }

        public IList<Employees>? Employees { get; set; } = new List<Employees>();
        public IList<Teams>? Teams { get; set; } = new List<Teams>();

    }
}
