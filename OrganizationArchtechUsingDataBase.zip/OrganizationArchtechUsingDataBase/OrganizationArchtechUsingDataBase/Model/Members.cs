﻿namespace OrganizationArchitecture.Model
{
    public class Members : BaseEntity
    {

        public string Name { get; set; }
        public decimal Salary { get; set; }
        public int Age { get; set; }
        public DateTime JoiningDate { get; set; }
        public string? Role { get; set; }
        public Guid TeamId { get; set; } //foreignkey
        public Teams? Teams { get; set; } //reference class
        public Guid? ReportsTo { get; set; }
        public int? TotalHoursWorked { get; set; }
        public int? TotalWorkLoad { get; set; }
        public Guid? OrganizationId { get; set; }//foreign key
        public Organization? Organization { get; set; } //reference class

    }
}
