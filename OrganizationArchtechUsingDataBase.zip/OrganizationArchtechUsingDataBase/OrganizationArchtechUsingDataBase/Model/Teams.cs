﻿namespace OrganizationArchitecture.Model
{
    public class Teams : BaseEntity
    {
        public string Name { get; set; }
        public string? ManagerName { get; set; }
        public Guid ManagerId { get; set; }
        public Guid OrganizationId { get; set; }//foreign key
        public Organization? Organization { get; set; }//reference class
        public IList<Members>? Members { get; set; }
    }
}
