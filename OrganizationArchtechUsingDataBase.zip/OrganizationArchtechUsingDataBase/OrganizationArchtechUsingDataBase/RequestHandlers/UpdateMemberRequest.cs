﻿using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;

namespace OrganizationArchitecture.RequestHandlers
{
    public class UpdateMemberRequest : MembersDto, IRequest<MembersDto>
    {

    }
    public class UpdateMemberRequestHanlder : IRequestHandler<UpdateMemberRequest, MembersDto>
    {
        private readonly DataBaseContext _dbContext;
        public UpdateMemberRequestHanlder(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<MembersDto> Handle(UpdateMemberRequest request, CancellationToken cancellationToken)
        {
            var member = await _dbContext.Members.FirstOrDefaultAsync(i => i.Id == request.Id && !i.IsDeleted);
            if (member == null)
            {
                throw new Exception("Member Not Found");
            }
            member = request.Adapt(member);
            _dbContext.Members.Update(member);
            await _dbContext.SaveChangesAsync();
            return member.Adapt<MembersDto>();
        }
    }
}
