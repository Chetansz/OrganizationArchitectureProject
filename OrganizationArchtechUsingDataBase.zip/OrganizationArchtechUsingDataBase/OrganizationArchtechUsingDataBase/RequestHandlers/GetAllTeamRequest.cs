﻿using Ardalis.Specification.EntityFrameworkCore;
using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;
using OrganizationArchitecture.SpecificationPattern;

namespace OrganizationArchitecture.RequestHandlers
{
    public class GetAllTeamRequest : IRequest<IEnumerable<TeamsDto>>
    {
        public string? Name { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public GetAllTeamRequest() { }
        public GetAllTeamRequest(string? name, int? pageSize, int? pageNumber)
        {
            Name = name;
            PageSize = pageSize;
            PageNumber = pageNumber;
        }
    }
    public class GetAllTeamRequestHandler : IRequestHandler<GetAllTeamRequest, IEnumerable<TeamsDto>>
    {
        private readonly DataBaseContext _dbContext;
        public GetAllTeamRequestHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<IEnumerable<TeamsDto>> Handle(GetAllTeamRequest request, CancellationToken cancellationToken)
        {
            var specification = new ActiveTeamSpecification(request.Name, request.PageNumber, request.PageSize);
            var query = SpecificationEvaluator.Default.GetQuery(_dbContext.Teams.AsQueryable(), specification: specification);
            var teams = await query.ToListAsync(cancellationToken);
            return teams.Adapt<IEnumerable<TeamsDto>>();
        }
    }
}
