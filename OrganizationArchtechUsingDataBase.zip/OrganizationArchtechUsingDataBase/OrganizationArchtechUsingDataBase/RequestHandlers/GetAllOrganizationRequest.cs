﻿using Ardalis.Specification.EntityFrameworkCore;
using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;
using OrganizationArchitecture.SpecificationPattern;

namespace OrganizationArchitecture.RequestHandlers
{
    public class GetAllOrganizationRequest : IRequest<IEnumerable<OrganizationDto>>
    {
        public string? Name { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public GetAllOrganizationRequest() { }
        public GetAllOrganizationRequest(string? name, int? pageSize, int? pageNumber)
        {
            Name = name;
            PageSize = pageSize;
            PageNumber = pageNumber;
        }
    }

    public class GetAllOrganizationRequestHandler : IRequestHandler<GetAllOrganizationRequest, IEnumerable<OrganizationDto>>
    {
        private readonly DataBaseContext _dbContext;

        public GetAllOrganizationRequestHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<OrganizationDto>> Handle(GetAllOrganizationRequest request, CancellationToken cancellationToken)
        {
            var specification = new ActiveOrganizationSpecification(request.Name, request.PageNumber, request.PageSize);
            var query = SpecificationEvaluator.Default.GetQuery(_dbContext.Organizations.AsQueryable(), specification: specification);
            var organizations = await query.ToListAsync(cancellationToken);
            if (organizations == null || !organizations.Any())
            {
                throw new Exception("Organizations not found");
            }
            return organizations.Adapt<IEnumerable<OrganizationDto>>();
        }
    }
}