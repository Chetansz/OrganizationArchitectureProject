﻿using Ardalis.Specification.EntityFrameworkCore;
using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;
using OrganizationArchitecture.SpecificationPattern;

namespace OrganizationArchitecture.RequestHandlers
{
    public class GetAllMemberRequest : IRequest<IEnumerable<MembersDto>>
    {
        public string? Name { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public GetAllMemberRequest() { }
        public GetAllMemberRequest(string? name, int? pageSize, int? pageNumber)
        {
            Name = name;
            PageSize = pageSize;
            PageNumber = pageNumber;
        }
    }

    public class GetAllMemberRequestHandler : IRequestHandler<GetAllMemberRequest, IEnumerable<MembersDto>>
    {
        private readonly DataBaseContext _dbContext;
        public GetAllMemberRequestHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<IEnumerable<MembersDto>> Handle(GetAllMemberRequest request, CancellationToken cancellationToken)
        {
            var specification = new ActiveMemberSpecification(request.Name, request.PageNumber, request.PageSize);
            var query = SpecificationEvaluator.Default.GetQuery(_dbContext.Members.AsQueryable(), specification: specification);
            var members = await query.ToListAsync(cancellationToken);
            if (members == null || !members.Any())
            {
                throw new Exception("Members Not Found");
            }
            return members.Adapt<IEnumerable<MembersDto>>();
        }

    }

}
