﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;

namespace OrganizationArchitecture.RequestHandlers
{
    public class DeleteTeamRequest : TeamsDto, IRequest
    {

    }
    public class DeleteTeamRequestHandle : IRequestHandler<DeleteTeamRequest>
    {
        private readonly DataBaseContext _dbContext;
        public DeleteTeamRequestHandle(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task Handle(DeleteTeamRequest request, CancellationToken cancellationToken)
        {
            var team = await _dbContext.Teams.FirstOrDefaultAsync(i => i.Id == request.Id);
            if (team == null)
            {
                throw new Exception("Team Not Found");
            }
            team.IsDeleted = true;
            await _dbContext.SaveChangesAsync();
        }
    }
}
