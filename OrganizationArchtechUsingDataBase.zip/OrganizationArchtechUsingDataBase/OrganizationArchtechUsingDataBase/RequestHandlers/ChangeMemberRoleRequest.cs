﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;

namespace OrganizationArchitecture.RequestHandlers
{
    public class ChangeMemberRoleRequest : MembersDto, IRequest<string>
    {

    }
    public class ChangeMemberRoleRequestHanlder : IRequestHandler<ChangeMemberRoleRequest, string>
    {
        private readonly DataBaseContext _dbContext;
        public ChangeMemberRoleRequestHanlder(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<string> Handle(ChangeMemberRoleRequest request, CancellationToken cancellationToken)
        {
            var member = await _dbContext.Members.FirstOrDefaultAsync(m => m.Id == request.Id, cancellationToken);
            if (member == null)
            {
                throw new Exception("Member not found to change.");
            }
            member.Role = request.Role;
            await _dbContext.SaveChangesAsync(cancellationToken);
            return member.Role;
        }
    }
}
