﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;

namespace OrganizationArchitecture.RequestHandlers
{
    public class GetSalaryEmployeeRequest : IRequest<decimal?>
    {
        public Guid Id { get; set; }
        public int Leaves { get; set; }
    }
    public class GetSalaryEmployeeRequestHandler : IRequestHandler<GetSalaryEmployeeRequest, decimal?>
    {
        private readonly DataBaseContext _dbContext;
        public GetSalaryEmployeeRequestHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<decimal?> Handle(GetSalaryEmployeeRequest request, CancellationToken cancellationToken)
        {
            var employee = await _dbContext.Employees.FirstOrDefaultAsync(i => i.Id == request.Id);
            decimal? deductionPerDay = employee?.Salary / 30;
            decimal? deductionSalary = deductionPerDay * request.Leaves;
            decimal? finalSalary = employee?.Salary - deductionSalary;
            return finalSalary;
        }

    }
}
