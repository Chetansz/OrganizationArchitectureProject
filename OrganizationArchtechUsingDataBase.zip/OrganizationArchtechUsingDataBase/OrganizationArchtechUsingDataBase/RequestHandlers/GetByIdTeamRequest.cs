﻿using Ardalis.Specification.EntityFrameworkCore;
using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;
using OrganizationArchitecture.SpecificationPattern;

namespace OrganizationArchitecture.RequestHandlers
{
    public class GetByIdTeamRequest : TeamsDto, IRequest<TeamsDto>
    {

    }
    public class GetByIdTeamRequestHandler : IRequestHandler<GetByIdTeamRequest, TeamsDto>
    {
        private readonly DataBaseContext _dbContext;
        public GetByIdTeamRequestHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<TeamsDto> Handle(GetByIdTeamRequest request, CancellationToken cancellationToken)
        {
            var specification = new TeamGetByIdSpecification(request.Id);
            var query = SpecificationEvaluator.Default.GetQuery(
                query: _dbContext.Teams.AsQueryable(),
                specification: specification
            );
            var team = await query.FirstOrDefaultAsync(cancellationToken);
            if (team == null || team.IsDeleted == false)
            {
                throw new Exception("Not Found");
            }
            return team.Adapt<TeamsDto>();
        }

    }

}
