﻿using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;

namespace OrganizationArchitecture.RequestHandlers
{
    public class GetByIdMemberRequest : MembersDto, IRequest<MembersDto>
    {
    }
    public class GetByIdMemberRequestHanler : IRequestHandler<GetByIdMemberRequest, MembersDto>
    {
        private readonly DataBaseContext _dbContext;
        public GetByIdMemberRequestHanler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<MembersDto> Handle(GetByIdMemberRequest request, CancellationToken cancellationToken)
        {
            var member = await _dbContext.Members.FirstOrDefaultAsync(i => i.Id == request.Id && !i.IsDeleted);
            if (member == null)
            {
                throw new Exception("Member Not Found");
            }
            return member.Adapt<MembersDto>();
        }

    }
}
