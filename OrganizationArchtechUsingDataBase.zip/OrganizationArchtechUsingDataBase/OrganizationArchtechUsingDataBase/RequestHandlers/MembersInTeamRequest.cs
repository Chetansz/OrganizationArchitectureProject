﻿using Ardalis.Specification.EntityFrameworkCore;
using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;
using OrganizationArchitecture.SpecificationPattern;

namespace OrganizationArchitecture.RequestHandlers
{
    public class MembersInTeamRequest : MembersDto, IRequest<IEnumerable<MembersDto>>
    {

    }
    public class MembersInTeamHandler : IRequestHandler<MembersInTeamRequest, IEnumerable<MembersDto>>
    {
        private readonly DataBaseContext _dbContext;
        public MembersInTeamHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<MembersDto>> Handle(MembersInTeamRequest request, CancellationToken cancellationToken)
        {
            var specification = new MembersInTeamSpecification(request.TeamId);
            var query = SpecificationEvaluator.Default.GetQuery(
                query: _dbContext.Members.AsQueryable(),
                specification: specification
            );
            var members = await query.ToListAsync(cancellationToken);
            if (members == null || !members.Any())
            {
                throw new Exception("No members found.");
            }
            return members.Adapt<IEnumerable<MembersDto>>();
        }
    }
}
