﻿using Ardalis.Specification.EntityFrameworkCore;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;
using OrganizationArchitecture.SpecificationPattern;

namespace OrganizationArchitecture.RequestHandlers
{
    public class GetTeamEffortsMembersRequest : MembersDto, IRequest<int?>
    {
    }

    public class GetTeamEffortsMembersRequestHandler : IRequestHandler<GetTeamEffortsMembersRequest, int?>
    {
        private readonly DataBaseContext _dbContext;
        public GetTeamEffortsMembersRequestHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<int?> Handle(GetTeamEffortsMembersRequest request, CancellationToken cancellationToken)
        {
            var specification = new TeamEffortsSpecification(request.Id);
            var query = SpecificationEvaluator.Default.GetQuery(
                _dbContext.Members.AsQueryable(),
                specification
            );
            var totalHoursWorked = await query.SumAsync(m => m.TotalHoursWorked, cancellationToken);
            return totalHoursWorked;
        }

    }
}
