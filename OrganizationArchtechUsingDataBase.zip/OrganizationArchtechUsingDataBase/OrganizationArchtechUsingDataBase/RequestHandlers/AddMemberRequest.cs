﻿using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;
using OrganizationArchitecture.Model;

namespace OrganizationArchitecture.RequestHandlers
{
    public class AddMemberRequest : MembersDto, IRequest<MembersDto>
    {

    }
    public class AddMemberRequestHandler : IRequestHandler<AddMemberRequest, MembersDto>
    {
        private readonly DataBaseContext _dbContext;
        public AddMemberRequestHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<MembersDto> Handle(AddMemberRequest request, CancellationToken cancellationToken)
        {
            var member = request.Adapt<Members>();
            var team = await _dbContext.Teams.FirstOrDefaultAsync(i => i.Id == member.TeamId);
            if (team != null)
            {
                member.ReportsTo = team.ManagerId;
            }
            var memberToEmployee = member.Adapt<Employees>();
            await _dbContext.Members.AddAsync(member);
            await _dbContext.Employees.AddAsync(memberToEmployee);
            await _dbContext.SaveChangesAsync();
            return member.Adapt<MembersDto>();
        }
    }
}
