﻿using Mapster;
using MediatR;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;
using OrganizationArchitecture.Model;

namespace OrganizationArchitecture.RequestHandlers
{
    public class AddOrganizationRequest : OrganizationDto, IRequest<OrganizationDto>
    {

    }
    public class AddOrganizationhandler : IRequestHandler<AddOrganizationRequest, OrganizationDto>
    {
        private readonly DataBaseContext _dbContext;
        public AddOrganizationhandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<OrganizationDto> Handle(AddOrganizationRequest request, CancellationToken cancellationToken)
        {
            var organization = request.Adapt<Organization>();
            await _dbContext.Organizations.AddAsync(organization);
            if (organization.Employees?.Any() ?? false)
            {
                foreach (var employee in organization.Employees)
                {
                    employee.OrganizationId = organization.Id;
                    await _dbContext.Employees.AddAsync(employee, cancellationToken);
                }
            }
            if (organization.Teams?.Any() ?? false)
            {
                foreach (var team in organization.Teams)
                {
                    team.ManagerId = Guid.NewGuid();
                    team.OrganizationId = organization.Id;
                    await _dbContext.Teams.AddAsync(team, cancellationToken);
                    if (team.Members?.Any() ?? false)
                    {
                        foreach (var member in team.Members)
                        {
                            member.OrganizationId = organization.Id;
                            member.TeamId = team.Id;
                            member.ReportsTo = team.ManagerId;
                            await _dbContext.Members.AddAsync(member, cancellationToken);
                            var memberAsEmployee = member.Adapt<Employees>();
                            memberAsEmployee.OrganizationId = organization.Id;
                            await _dbContext.Employees.AddAsync(memberAsEmployee, cancellationToken);
                        }
                    }
                }
            }
            await _dbContext.SaveChangesAsync(cancellationToken);
            return organization.Adapt<OrganizationDto>();
        }
    }
}
