﻿using Mapster;
using MediatR;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;
using OrganizationArchitecture.Model;

namespace OrganizationArchitecture.RequestHandlers
{
    public class AddEmployeeRequest : EmployeesDto, IRequest<EmployeesDto>
    {

    }
    public class AddEmployeeHandler : IRequestHandler<AddEmployeeRequest, EmployeesDto>
    {
        private readonly DataBaseContext _dbContext;

        public AddEmployeeHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<EmployeesDto> Handle(AddEmployeeRequest request, CancellationToken cancellationToken)
        {
            var employee = request.Adapt<Employees>();
            await _dbContext.Employees.AddAsync(employee, cancellationToken);
            await _dbContext.SaveChangesAsync(cancellationToken);
            return employee.Adapt<EmployeesDto>();
        }

    }

}
