﻿using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;

namespace OrganizationArchitecture.RequestHandlers
{
    public class UpdateEmployeeRequest : EmployeesDto, IRequest<EmployeesDto>
    {
    }
    public class UpdateEmployeeRequestHandler : IRequestHandler<UpdateEmployeeRequest, EmployeesDto>
    {
        private readonly DataBaseContext _dbContext;
        public UpdateEmployeeRequestHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<EmployeesDto> Handle(UpdateEmployeeRequest request, CancellationToken cancellationToken)
        {
            var employee = await _dbContext.Employees.FirstOrDefaultAsync(i => i.Id == request.Id && !i.IsDeleted);
            if (employee == null)
            {
                throw new Exception("Employee not found");
            }
            employee = request.Adapt(employee);
            _dbContext.Employees.Update(employee);
            await _dbContext.SaveChangesAsync();
            return employee.Adapt<EmployeesDto>();
        }
    }
}
