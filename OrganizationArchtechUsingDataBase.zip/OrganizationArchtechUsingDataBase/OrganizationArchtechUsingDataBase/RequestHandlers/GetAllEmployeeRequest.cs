﻿using Ardalis.Specification.EntityFrameworkCore;
using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;
using OrganizationArchitecture.SpecificationPattern;

namespace OrganizationArchitecture.RequestHandlers
{
    public class GetAllEmployeeRequest : IRequest<IEnumerable<EmployeesDto>>
    {
        public string? Name { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public GetAllEmployeeRequest() { }

    }

    public class EmployeeGetAllRequestHandler : IRequestHandler<GetAllEmployeeRequest, IEnumerable<EmployeesDto>>
    {
        private readonly DataBaseContext _dbContext;

        public EmployeeGetAllRequestHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<EmployeesDto>> Handle(GetAllEmployeeRequest request, CancellationToken cancellationToken)
        {
            var specification = new ActiveEmployeeSpecification(request.Name, request.PageNumber, request.PageSize);
            var query = SpecificationEvaluator.Default.GetQuery(
                query: _dbContext.Employees.AsQueryable(),
                specification: specification
            );
            var employees = await query.ToListAsync(cancellationToken);
            return employees.Adapt<IEnumerable<EmployeesDto>>() ?? Enumerable.Empty<EmployeesDto>();
        }

    }
}
