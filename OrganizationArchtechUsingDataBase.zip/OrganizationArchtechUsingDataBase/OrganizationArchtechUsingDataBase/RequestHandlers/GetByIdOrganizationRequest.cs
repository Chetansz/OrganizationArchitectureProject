﻿using Ardalis.Specification.EntityFrameworkCore;
using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;
using OrganizationArchitecture.SpecificationPattern;

namespace OrganizationArchitecture.RequestHandlers
{
    public class GetByIdOrganizationRequest : OrganizationDto, IRequest<OrganizationDto>
    {
    }
    public class GetByIdOrganizationRequestHandler : IRequestHandler<GetByIdOrganizationRequest, OrganizationDto>
    {
        private readonly DataBaseContext _dbContext;
        public GetByIdOrganizationRequestHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<OrganizationDto> Handle(GetByIdOrganizationRequest request, CancellationToken cancellationToken)
        {
            var specification = new OrganizationGetByIdSpecification(request.Id);
            var query = SpecificationEvaluator.Default.GetQuery(_dbContext.Organizations.AsQueryable(), specification: specification);
            var organization = await query.FirstOrDefaultAsync(cancellationToken);
            if (organization == null || organization.IsDeleted == true)
            {
                throw new Exception("Not Found");
            }
            return organization.Adapt<OrganizationDto>();
        }

    }
}
