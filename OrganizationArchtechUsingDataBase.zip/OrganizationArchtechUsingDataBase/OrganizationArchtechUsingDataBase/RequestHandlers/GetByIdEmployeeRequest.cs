﻿using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;

namespace OrganizationArchitecture.RequestHandlers
{
    public class GetByIdEmployeeRequest : IRequest<EmployeesDto>
    {
        public Guid Id { get; set; }
    }

    public class GetByIdEmployeesRequestHandler : IRequestHandler<GetByIdEmployeeRequest, EmployeesDto>
    {
        private readonly DataBaseContext _dbContext;
        public GetByIdEmployeesRequestHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<EmployeesDto> Handle(GetByIdEmployeeRequest request, CancellationToken cancellationToken)
        {
            var employee = await _dbContext.Employees.FirstOrDefaultAsync(i => i.Id == request.Id && !i.IsDeleted);
            if (employee == null)
            {
                throw new Exception($"Employee with given id {request.Id} not found");
            }
            return employee.Adapt<EmployeesDto>();
        }
    }
}
