﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;

namespace OrganizationArchitecture.RequestHandlers
{
    public class GetTeamManagerRequest : TeamsDto, IRequest<string>
    {
    }
    public class GetTeamManagerRequestHandler : IRequestHandler<GetTeamManagerRequest, string>
    {
        private readonly DataBaseContext _dbContext;
        public GetTeamManagerRequestHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<string> Handle(GetTeamManagerRequest request, CancellationToken cancellationToken)
        {
            var manager = await _dbContext.Members.FirstOrDefaultAsync(i => i.ReportsTo == request.Id, cancellationToken);
            if (manager == null)
            {
                throw new Exception($"No Manager Found With Id {request.Id}");
            }
            return manager.Name;
        }
    }
}
