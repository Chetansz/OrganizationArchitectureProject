﻿using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;
namespace OrganizationArchitecture.RequestHandlers
{
    public class ReassignMemberRequest : MembersDto, IRequest<MembersDto>
    {
    }
    public class ReassignMemberRequestHandler : IRequestHandler<ReassignMemberRequest, MembersDto>
    {
        private readonly DataBaseContext _dbContext;
        public ReassignMemberRequestHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<MembersDto> Handle(ReassignMemberRequest request, CancellationToken cancellationToken)
        {
            var member = await _dbContext.Members.FirstOrDefaultAsync(m => m.Id == request.Id, cancellationToken);
            if (member == null)
            {
                throw new Exception("Member not found with given ID.");
            }
            var teamExists = await _dbContext.Teams.AnyAsync(t => t.Id == request.TeamId, cancellationToken);
            if (!teamExists)
            {
                throw new Exception("Invalid TeamId. The team does not exist.");
            }
            request.Adapt(member);
            member.TeamId = request.TeamId;
            await _dbContext.SaveChangesAsync(cancellationToken);
            return member.Adapt<MembersDto>();
        }
    }
}
