﻿using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;

namespace OrganizationArchitecture.RequestHandlers
{
    public class UpdateTeamRequest : TeamsDto, IRequest<TeamsDto>
    {

    }
    public class UpdateTeamReqestHandler : IRequestHandler<UpdateTeamRequest, TeamsDto>
    {
        private readonly DataBaseContext _dbContext;
        public UpdateTeamReqestHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<TeamsDto> Handle(UpdateTeamRequest request, CancellationToken cancellationToken)
        {
            var team = await _dbContext.Teams.FirstOrDefaultAsync(i => i.Id == request.Id && !i.IsDeleted);
            if (team == null)
            {
                throw new Exception("Team not found");
            }
            team = request.Adapt(team);
            if (team.Members?.Any() ?? false)
            {
                foreach (var member in team.Members)
                {
                    var existingMember = await _dbContext.Members.FirstOrDefaultAsync(i => i.Id == member.Id);
                    if (existingMember != null)
                    {
                        existingMember = member.Adapt(existingMember);
                        _dbContext.Members.Update(existingMember);
                    }
                }
            }
            await _dbContext.SaveChangesAsync();
            return team.Adapt<TeamsDto>();
        }

    }
}
