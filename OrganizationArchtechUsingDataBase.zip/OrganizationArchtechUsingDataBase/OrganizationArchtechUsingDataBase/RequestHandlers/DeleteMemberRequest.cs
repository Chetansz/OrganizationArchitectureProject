﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;

namespace OrganizationArchitecture.RequestHandlers
{
    public class DeleteMemberRequest : MembersDto, IRequest
    {

    }
    public class DeleteMemberRequestHandler : IRequestHandler<DeleteMemberRequest>
    {
        private readonly DataBaseContext _dbContext;
        public DeleteMemberRequestHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task Handle(DeleteMemberRequest request, CancellationToken cancellationToken)
        {
            var member = await _dbContext.Members.FirstOrDefaultAsync(i => i.Id == request.Id);
            if (member == null)
            {
                throw new Exception("Member Not Found");
            }
            member.IsDeleted = true;
            await _dbContext.SaveChangesAsync();
        }
    }
}
