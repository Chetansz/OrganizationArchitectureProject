﻿using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;
using OrganizationArchitecture.Model;

namespace OrganizationArchitecture.RequestHandlers
{
    public class AddTeamRequest : TeamsDto, IRequest<TeamsDto>
    {

    }
    public class AddTeamRequestHandler : IRequestHandler<AddTeamRequest, TeamsDto>
    {
        private readonly DataBaseContext _dbContext;
        public AddTeamRequestHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<TeamsDto> Handle(AddTeamRequest request, CancellationToken cancellationToken)
        {
            var teamDetails = request.Adapt<Teams>();
            var managerAsEmployee = await _dbContext.Employees
                .FirstOrDefaultAsync(e => e.Name == request.ManagerName, cancellationToken);
            if (managerAsEmployee == null)
            {
                throw new Exception("Invalid Manager: Please provide a valid manager.");
            }
            teamDetails.ManagerId = managerAsEmployee.Id;
            await _dbContext.Teams.AddAsync(teamDetails, cancellationToken);
            if (teamDetails.Members?.Any() ?? false)
            {
                foreach (var member in teamDetails.Members)
                {
                    member.ReportsTo = teamDetails.ManagerId;
                    member.OrganizationId = teamDetails.OrganizationId;
                    member.TeamId = teamDetails.Id;
                }
                await _dbContext.Members.AddRangeAsync(teamDetails.Members, cancellationToken);
            }
            await _dbContext.SaveChangesAsync(cancellationToken);
            return teamDetails.Adapt<TeamsDto>();
        }
    }
}
