﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using OrganizationArchitecture.Data;
using OrganizationArchitecture.DTOs;

namespace OrganizationArchitecture.RequestHandlers
{
    public class DeleteEmployeeRequest : EmployeesDto, IRequest
    {
    }
    public class DeleteEmployeeRequestHandler : IRequestHandler<DeleteEmployeeRequest>
    {
        private readonly DataBaseContext _dbContext;
        public DeleteEmployeeRequestHandler(DataBaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task Handle(DeleteEmployeeRequest request, CancellationToken cancellationToken)
        {
            var employee = await _dbContext.Employees.FirstOrDefaultAsync(i => i.Id == request.Id);
            if (employee == null)
            {
                throw new Exception("Employee Not Found");
            }
            employee.IsDeleted = true;
            await _dbContext.SaveChangesAsync();
        }

    }
}
