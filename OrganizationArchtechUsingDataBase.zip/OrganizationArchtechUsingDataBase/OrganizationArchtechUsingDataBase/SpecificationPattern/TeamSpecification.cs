﻿using Ardalis.Specification;
using OrganizationArchitecture.Model;

namespace OrganizationArchitecture.SpecificationPattern
{
    public class ActiveTeamSpecification : Specification<Teams>
    {
        public ActiveTeamSpecification(string? name, int? pageNumber, int? pageSize)
        {
            Query.Where(i => !i.IsDeleted).Include(i => i.Members);
            if (!string.IsNullOrWhiteSpace(name))
            {
                Query.Where(i => i.Name.Contains(name) && !i.IsDeleted);
            }
            if (pageNumber.HasValue && pageSize.HasValue)
            {
                Query.Skip((pageNumber.Value - 1) * pageSize.Value)
                    .Take(pageSize.Value);
            }
        }
    }
    public class TeamGetByIdSpecification : Specification<Teams>
    {
        public TeamGetByIdSpecification(Guid id)
        {
            Query.Where(i => i.Id == id && !i.IsDeleted).Include(i => i.Members);
        }
    }
    public class TeamGetManagerByIdSpecification : Specification<Teams>
    {
        public TeamGetManagerByIdSpecification(Guid managerId)
        {
            Query.Where(i => i.ManagerId == managerId && !i.IsDeleted);
        }
    }
}
