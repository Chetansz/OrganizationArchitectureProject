﻿using Ardalis.Specification;
using OrganizationArchitecture.Model;

namespace OrganizationArchitecture.SpecificationPattern
{
    public class ActiveMemberSpecification : Specification<Members>
    {
        public ActiveMemberSpecification(string? name, int? pageNumber, int? pageSize)
        {
            Query.Where(i => !i.IsDeleted);
            if (!string.IsNullOrWhiteSpace(name))
            {
                Query.Where(i => i.Name.Contains(name));
            }
            if (pageNumber.HasValue && pageSize.HasValue)
            {
                Query.Skip((pageNumber.Value - 1) * pageSize.Value)
                    .Take(pageSize.Value);
            }
        }
    }
    public class TeamEffortsSpecification : Specification<Members>
    {
        public TeamEffortsSpecification(Guid teamId)
        {
            Query.Where(m => m.TeamId == teamId);
        }
    }
    public class MembersInTeamSpecification : Specification<Members>
    {
        public MembersInTeamSpecification(Guid teamId)
        {
            Query.Where(m => m.TeamId == teamId);
        }
    }
}
