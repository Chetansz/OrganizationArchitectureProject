﻿using Ardalis.Specification;
using OrganizationArchitecture.Model;

namespace OrganizationArchitecture.SpecificationPattern
{
    public class ActiveEmployeeSpecification : Specification<Employees>
    {
        public ActiveEmployeeSpecification(string? name, int? pageNumber, int? pageSize)
        {
            Query.Where(e => !e.IsDeleted);
            if (!string.IsNullOrWhiteSpace(name))
            {
                Query.Where(e => e.Name.Contains(name));
            }
            if (pageNumber.HasValue && pageSize.HasValue)
            {
                Query.Skip((pageNumber.Value - 1) * pageSize.Value)
                     .Take(pageSize.Value);
            }
        }
    }
}
