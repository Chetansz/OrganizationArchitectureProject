﻿using Ardalis.Specification;
using OrganizationArchitecture.Model;

namespace OrganizationArchitecture.SpecificationPattern
{
    public class ActiveOrganizationSpecification : Specification<Organization>
    {
        public ActiveOrganizationSpecification(string? name, int? pageNumber, int? pageSize)
        {
            Query.Where(i => !i.IsDeleted).Include(i => i.Teams).ThenInclude(i => i.Members).Include(i => i.Employees);
            if (!string.IsNullOrWhiteSpace(name))
            {
                Query.Where(i => i.Name.Contains(name) && !i.IsDeleted);
            }
            if (pageNumber.HasValue && pageSize.HasValue)
            {
                Query.Skip((pageNumber.Value - 1) * pageSize.Value)
                    .Take(pageSize.Value);
            }
        }
    }
    public class OrganizationGetByIdSpecification : Specification<Organization>
    {
        public OrganizationGetByIdSpecification(Guid id)
        {
            Query.Where(i => i.Id == id && !i.IsDeleted)
             .Include(i => i.Teams)
             .ThenInclude(t => t.Members)
             .Include(i => i.Employees);
        }
    }
}
