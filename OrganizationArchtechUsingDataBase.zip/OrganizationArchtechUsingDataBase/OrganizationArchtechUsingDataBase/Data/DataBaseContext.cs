﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using OrganizationArchitecture.Model;

namespace OrganizationArchitecture.Data

{
    public class DataBaseContext : DbContext
    {
        public DataBaseContext(DbContextOptions<DataBaseContext> options)
        : base(options) { }

        public DbSet<Organization> Organizations { get; set; }
        public DbSet<Employees> Employees { get; set; }
        public DbSet<Members> Members { get; set; }
        public DbSet<Teams> Teams { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Organization>()
                .HasKey(e => e.Id);
            modelBuilder.Entity<Employees>()
                .HasKey(e => e.Id);
            modelBuilder.Entity<Members>()
                .HasKey(e => e.Id);
            modelBuilder.Entity<Teams>()
                .HasKey(e => e.Id);

            modelBuilder.Entity<Teams>()
                .HasOne<Organization>(t => t.Organization)
                .WithMany(o => o.Teams)
                .HasForeignKey(t => t.OrganizationId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Members>()
                .HasOne<Teams>(m => m.Teams)
                .WithMany(t => t.Members)
                .HasForeignKey(m => m.TeamId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Employees>()
                .HasOne<Organization>(e => e.Organization)
                .WithMany(o => o.Employees)
                .HasForeignKey(e => e.OrganizationId)
                .OnDelete(DeleteBehavior.Cascade);
        }
        public override int SaveChanges()
        {
            UpdateBaseProperties();
            return base.SaveChanges();
        }
        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            UpdateBaseProperties();
            return await base.SaveChangesAsync(cancellationToken);
        }
        public void UpdateBaseProperties()
        {
            var entries = ChangeTracker.Entries<BaseEntity>();
            foreach (var entry in entries)
            {
                if (entry.State == EntityState.Added)
                {
                    entry.Entity.CreatedOn = DateTime.UtcNow;
                    entry.Entity.CreatedBy = "chetan";

                }
                if (entry.State == EntityState.Modified)
                {
                    entry.Entity.ModifiedOn = DateTime.UtcNow;
                    entry.Entity.ModifiedBy = "chetan";

                }
            }
        }
    }
}
