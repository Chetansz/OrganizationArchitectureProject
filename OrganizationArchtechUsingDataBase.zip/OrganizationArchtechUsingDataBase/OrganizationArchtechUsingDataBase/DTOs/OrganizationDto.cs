﻿namespace OrganizationArchitecture.DTOs
{
    public class OrganizationDto : BaseEntityDto
    {
        public string? Name { get; set; }
        public IList<EmployeesDto>? Employees { get; set; } = new List<EmployeesDto>();
        public IList<TeamsDto>? Teams { get; set; } = new List<TeamsDto>();
    }
}
