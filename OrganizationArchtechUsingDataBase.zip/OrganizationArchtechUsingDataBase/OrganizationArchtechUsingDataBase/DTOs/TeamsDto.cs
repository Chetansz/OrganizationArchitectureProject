﻿namespace OrganizationArchitecture.DTOs
{
    public class TeamsDto : BaseEntityDto
    {
        public string Name { get; set; }
        public string? ManagerName { get; set; }
        public Guid OrganizationId { get; set; }
        public IList<MembersDto>? Members { get; set; } 
    }
}
