﻿namespace OrganizationArchitecture.DTOs
{
    public class EmployeesDto : BaseEntityDto
    {
        public string? Name { get; set; }
        public decimal? Salary { get; set; }
        public int? Age { get; set; }
        public DateTime? JoiningDate { get; set; }
        public Guid OrganizationId { get; set; }
    }
}
