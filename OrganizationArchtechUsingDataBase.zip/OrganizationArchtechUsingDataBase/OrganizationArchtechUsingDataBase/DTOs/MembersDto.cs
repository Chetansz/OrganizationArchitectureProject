﻿namespace OrganizationArchitecture.DTOs
{
    public class MembersDto : BaseEntityDto
    {
        public string Name { get; set; }
        public decimal? Salary { get; set; }
        public int Age { get; set; }
        public DateTime JoiningDate { get; set; }
        public string? Role { get; set; }
        public Guid TeamId { get; set; }
        public Guid? ReportsTo { get; set; }
        public int? TotalHoursWorked { get; set; }
        public int? TotalWorkLoad { get; set; }
        public Guid OrganizationId { get; set; }
    }
}
