﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using OrganizationArchitecture.DTOs;
using OrganizationArchitecture.RequestHandlers;
using OrganizationArchitecture.Response;

namespace OrganizationArchitecture.Controllers
{
    public class MembersController : BaseApiController
    {
        private IMediator _mediator;
        public MembersController(IMediator mediator)
        {
            _mediator = mediator;
        }
        [HttpGet]
        public async Task<Response<IEnumerable<MembersDto>>> GetAllAsync([FromQuery] GetAllMemberRequest request)
        {
            var members = await _mediator.Send(request);
            return new Response<IEnumerable<MembersDto>>(200, "Success", members);
        }
        [HttpGet("{id}")]
        public async Task<Response<MembersDto>> GetByIdAsync(Guid id)
        {
            var request = new GetByIdMemberRequest { Id = id };
            var member = await _mediator.Send(request);
            if (member == null)
            {
                throw new Exception("Member not found");
            }
            return new Response<MembersDto>(200, "Success", member);
        }
        [HttpPost]
        public async Task<Response<MembersDto>> AddAsync(AddMemberRequest request)
        {
            var member = await _mediator.Send(request);
            return new Response<MembersDto>(201, "Member added successfully", member);
        }
        [HttpPut]
        public async Task<Response<MembersDto>> UpdateAsync(Guid id, UpdateMemberRequest request)
        {
            request.Id = id;
            var updatedMember = await _mediator.Send(request);
            return new Response<MembersDto>(200, "Member updated successfully", updatedMember);
        }
        [HttpDelete]
        public async Task<Response<string>> DeleteAsync(Guid id)
        {
            var request = new DeleteMemberRequest { Id = id };
            await _mediator.Send(request);
            return new Response<string>(200, "Member deleted successfully", null);
        }
        [HttpPatch("ChangeRole")]
        public async Task<Response<string>> ChangeRole(Guid id, string role)
        {
            var request = new ChangeMemberRoleRequest { Id = id, Role = role };
            await _mediator.Send(request);
            return new Response<string>(200, "Member changed role successfully", null);
        }
        [HttpPut("Reassign")]
        public async Task<Response<MembersDto>> ReassignTeam(Guid id, ReassignMemberRequest request)
        {
            request.Id = id;
            var reassignedMember = await _mediator.Send(request);
            return new Response<MembersDto>(200, "Member Reassigned Successfullyy", reassignedMember);
        }
        [HttpGet("MembersInTeam")]
        public async Task<Response<IEnumerable<MembersDto>>> TeamMembers(Guid teamId)
        {
            var request = new MembersInTeamRequest { TeamId = teamId };
            var membersInTeam = await _mediator.Send(request);
            return new Response<IEnumerable<MembersDto>>(200, "Success", membersInTeam);
        }

        [HttpGet("TeamEfforts")]
        public async Task<Response<int?>> TeamEfforts(Guid id)
        {
            var request = new GetTeamEffortsMembersRequest { Id = id };
            var efforts = await _mediator.Send(request);
            return new Response<int?>(200, "Members in Team retrived successfully", efforts);
        }
    }
}
