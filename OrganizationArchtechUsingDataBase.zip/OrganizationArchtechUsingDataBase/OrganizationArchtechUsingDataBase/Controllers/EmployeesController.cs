﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using OrganizationArchitecture.DTOs;
using OrganizationArchitecture.RequestHandlers;
using OrganizationArchitecture.Response;

namespace OrganizationArchitecture.Controllers
{
    public class EmployeesController : BaseApiController
    {
        private readonly IMediator _mediator;

        public EmployeesController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<Response<IEnumerable<EmployeesDto>>> GetAllAsync([FromQuery] GetAllEmployeeRequest request)
        {
            var employees = await _mediator.Send(request);
            return new Response<IEnumerable<EmployeesDto>>(200, "Success", employees);
        }

        [HttpGet("{id}")]
        public async Task<Response<EmployeesDto>> GetByIdAsync(Guid id)
        {
            var request = new GetByIdEmployeeRequest { Id = id };
            var employee = await _mediator.Send(request);

            if (employee == null)
            {
                return new Response<EmployeesDto>(404, "Employee not found", null);
            }

            return new Response<EmployeesDto>(200, "Success", employee);
        }


        [HttpPost]
        public async Task<Response<EmployeesDto>> AddAsync(AddEmployeeRequest request)
        {
            var employee = await _mediator.Send(request);
            return new Response<EmployeesDto>(201, "Employee added successfully", employee);
        }

        [HttpPut("{id}")]
        public async Task<Response<EmployeesDto>> UpdateAsync(Guid id, UpdateEmployeeRequest request)
        {
            request.Id = id;
            var updatedEmployee = await _mediator.Send(request);

            if (updatedEmployee == null)
            {
                return new Response<EmployeesDto>(404, "Employee not found", null);
            }
            return new Response<EmployeesDto>(200, "Employee updated successfully", updatedEmployee);
        }

        [HttpDelete("{id}")]
        public async Task<Response<string>> DeleteAsync(Guid id)
        {
            var request = new DeleteEmployeeRequest { Id = id };
            await _mediator.Send(request);

            return new Response<string>(200, "Employee deleted successfully", null);
        }

        [HttpGet("Salary")]
        public async Task<Response<decimal?>> GetSalaryAsync(Guid id, int leaves)
        {
            var request = new GetSalaryEmployeeRequest { Id = id, Leaves = leaves };
            var salary = await _mediator.Send(request);

            if (salary == null)
            {
                return new Response<decimal?>(404, "Salary information not found", null);
            }

            return new Response<decimal?>(200, "Salary retrieved successfully", salary);
        }
    }
}
