﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using OrganizationArchitecture.DTOs;
using OrganizationArchitecture.RequestHandlers;
using OrganizationArchitecture.Response;

namespace OrganizationArchitecture.Controllers
{
    public class TeamsController : BaseApiController
    {
        private IMediator _mediator;
        public TeamsController(IMediator mediator)
        {
            _mediator = mediator;
        }
        [HttpGet]
        public async Task<Response<IEnumerable<TeamsDto>>> GetAllAsync([FromQuery] GetAllTeamRequest request)
        {
            var team = await _mediator.Send(request);
            return new Response<IEnumerable<TeamsDto>>(200, "Success", team);
        }
        [HttpGet("{id}")]
        public async Task<Response<TeamsDto>> GetById(Guid id)
        {
            var request = new GetByIdTeamRequest { Id = id };
            var team = await _mediator.Send(request);
            return new Response<TeamsDto>(200, "Success", team);
        }
        [HttpPost]
        public async Task<Response<TeamsDto>> AddAsync(AddTeamRequest request)
        {
            var team = await _mediator.Send(request);
            return new Response<TeamsDto>(201, "Team added successfully", team);
        }
        [HttpPut]
        public async Task<Response<TeamsDto>> UpdateAsync(Guid id, UpdateTeamRequest request)
        {
            request.Id = id;
            var updatedTeam = await _mediator.Send(request);
            return new Response<TeamsDto>(200, "Team Updated Sunccessfully", updatedTeam);
        }

        [HttpDelete]
        public async Task<Response<string>> DeleteAsync(Guid id)
        {
            var request = new DeleteTeamRequest { Id = id };
            await _mediator.Send(request);
            return new Response<string>(200, "Member deleted successfully", null);
        }
        [HttpGet("Manager")]
        public async Task<Response<string>> GetManager(Guid managerId)
        {
            var request = new GetTeamManagerRequest { Id = managerId };
            var manager = await _mediator.Send(request);
            return new Response<string>(200, "Manager FetchedSuccesfully", manager);
        }
    }
}
