﻿using Microsoft.AspNetCore.Mvc;

namespace OrganizationArchitecture.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BaseApiController : ControllerBase
    {

    }

}
