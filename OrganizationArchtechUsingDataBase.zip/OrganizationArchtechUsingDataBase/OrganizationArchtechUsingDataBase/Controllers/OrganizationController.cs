﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using OrganizationArchitecture.DTOs;
using OrganizationArchitecture.RequestHandlers;
using OrganizationArchitecture.Response;

namespace OrganizationArchitecture.Controllers
{
    public class OrganizationController : BaseApiController
    {
        private IMediator _mediator;
        public OrganizationController(IMediator mediator)
        {
            _mediator = mediator;
        }
        [HttpGet]
        public async Task<Response<IEnumerable<OrganizationDto>>> GetAllAsync([FromQuery] GetAllOrganizationRequest request)
        {
            var organizations = await _mediator.Send(request);
            return new Response<IEnumerable<OrganizationDto>>(200, "Success", organizations);
        }
        [HttpGet("{id}")]
        public async Task<Response<OrganizationDto>> GetByIdAsync(Guid id)
        {
            var request = new GetByIdOrganizationRequest { Id = id };
            var organization = await _mediator.Send(request);
            return new Response<OrganizationDto>(200, "Success", organization);
        }
        [HttpPost]
        public async Task<Response<OrganizationDto>> AddAsync(AddOrganizationRequest request)
        {
            var organization = await _mediator.Send(request);
            return new Response<OrganizationDto>(201, "Organization added successfully", organization);
        }
    }
}
